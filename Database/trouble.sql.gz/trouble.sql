-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Σύστημα: localhost
-- Χρόνος δημιουργίας: 21 Δεκ 2010, στις 06:43 ��
-- Έκδοση Διακομιστή: 5.1.41
-- Έκδοση PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Βάση: `troubleshooting`
--
CREATE DATABASE `troubleshooting` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `troubleshooting`;

-- --------------------------------------------------------

--
-- Δομή Πίνακα για τον Πίνακα `cddvd`
--

CREATE TABLE IF NOT EXISTS `cddvd` (
  `idCD-DVD` int(11) NOT NULL AUTO_INCREMENT,
  `start` int(11) DEFAULT NULL,
  `stop` int(11) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`idCD-DVD`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- 'Αδειασμα δεδομένων του πίνακα `cddvd`
--

INSERT INTO `cddvd` (`idCD-DVD`, `start`, `stop`, `text`) VALUES
(1, 1, 2, 'I/O Cable is Connected'),
(2, 1, 3, 'I/O Cable is not Connected'),
(3, 3, 0, 'Connect I/O Cable <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(4, 2, 4, 'Power Supply Cable is Connected'),
(5, 2, 5, 'Power Supply Cable is not Connected'),
(6, 5, 0, 'Connnect Power Supply Cable <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(7, 4, 0, 'Contact your Supplier <img src="images/exclam.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/> <a href="links.html">cd/dvd drive companies</a>');

-- --------------------------------------------------------

--
-- Δομή Πίνακα για τον Πίνακα `hdd`
--

CREATE TABLE IF NOT EXISTS `hdd` (
  `idHDD` int(11) NOT NULL AUTO_INCREMENT,
  `start` int(11) DEFAULT NULL,
  `stop` int(11) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`idHDD`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- 'Αδειασμα δεδομένων του πίνακα `hdd`
--

INSERT INTO `hdd` (`idHDD`, `start`, `stop`, `text`) VALUES
(1, 1, 2, 'SATA cable is connected'),
(2, 1, 3, 'SATA cable is not connected'),
(3, 3, 0, 'Connect SATA cable <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(4, 2, 4, 'Power Supply Cable is Connnected'),
(5, 2, 5, 'Power Supply Cable is not Connnected'),
(6, 5, 0, 'Connect Power Supply Cable <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(7, 4, 0, 'Contact your Supplie <img src="images/exclam.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/> <a href="links.html">HDD companies</a>');

-- --------------------------------------------------------

--
-- Δομή Πίνακα για τον Πίνακα `keyboard`
--

CREATE TABLE IF NOT EXISTS `keyboard` (
  `idkeyboard` int(11) NOT NULL AUTO_INCREMENT,
  `start` int(11) DEFAULT NULL,
  `stop` int(11) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`idkeyboard`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- 'Αδειασμα δεδομένων του πίνακα `keyboard`
--

INSERT INTO `keyboard` (`idkeyboard`, `start`, `stop`, `text`) VALUES
(1, 1, 2, 'Keyboard is wired'),
(2, 1, 3, 'Keyboard is wireless'),
(3, 3, 4, 'Transmitter is connected'),
(4, 3, 5, 'Transmitter is not connected'),
(5, 5, 0, 'Connect transmitter <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(6, 4, 6, 'Batteries are ok'),
(7, 4, 7, 'Batteries are not ok'),
(8, 7, 0, 'Install batteries <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(9, 6, 8, 'Keyboard is synchronized'),
(10, 6, 9, 'Keyboard is not synchrozized'),
(11, 9, 0, 'Synchronize keyboard <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(12, 8, 0, 'Contact your supplier <img src="images/exclam.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/> <a href="links.html">Keyboard companies</a>'),
(13, 2, 10, 'Cable is connected'),
(14, 2, 11, 'Cable is not connected'),
(15, 11, 0, 'Connect cable <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(16, 10, 0, 'Contact your supplier <img src="images/exclam.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/> <a href="links.html">Keyboard companies</a>'),
(17, 11, 0, 'Maybe is  ur gpu wrong try this-> <a href="http://localhost/that/que.php?node=1&part=+monitorgpu" > CLICK </a> ');

-- --------------------------------------------------------

--
-- Δομή Πίνακα για τον Πίνακα `monitorgpu`
--

CREATE TABLE IF NOT EXISTS `monitorgpu` (
  `idMonitorGPU` int(11) NOT NULL AUTO_INCREMENT,
  `start` int(11) DEFAULT NULL,
  `stop` int(11) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`idMonitorGPU`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- 'Αδειασμα δεδομένων του πίνακα `monitorgpu`
--

INSERT INTO `monitorgpu` (`idMonitorGPU`, `start`, `stop`, `text`) VALUES
(1, 1, 3, 'Power Supply Cable is connected'),
(2, 1, 2, 'Power Supply Cable is not connected'),
(3, 2, 0, 'Connect Power Supply Cable <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(4, 3, 4, 'VGA Cable is not connected'),
(5, 3, 5, 'VGA Cable is connected'),
(6, 4, 0, 'Connect VGA Cable <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(7, 5, 6, 'GPU is connected'),
(8, 5, 7, 'GPU is not connected'),
(9, 7, 0, 'Connect GPU <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(10, 6, 0, 'Contact your Supplier <img src="images/exclam.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/> <a href="links.html">Monitor companies</a>');

-- --------------------------------------------------------

--
-- Δομή Πίνακα για τον Πίνακα `mouse`
--

CREATE TABLE IF NOT EXISTS `mouse` (
  `idmouse` int(11) NOT NULL AUTO_INCREMENT,
  `start` int(11) DEFAULT NULL,
  `stop` int(11) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`idmouse`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- 'Αδειασμα δεδομένων του πίνακα `mouse`
--

INSERT INTO `mouse` (`idmouse`, `start`, `stop`, `text`) VALUES
(1, 1, 2, 'Mouse is wired'),
(2, 1, 3, 'Mouse is wireless'),
(3, 3, 4, 'Transmitter is connected'),
(4, 3, 5, 'Transmitter is not connected'),
(5, 5, 0, 'Connect transmitter <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(6, 4, 6, 'Batteries are ok'),
(7, 4, 7, 'Batteries are not ok'),
(8, 7, 0, 'Put batteries <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(9, 6, 8, 'Mouse is synchrinized'),
(10, 6, 9, 'Mouse is not synchrozized'),
(11, 9, 0, 'Synchronize mouse <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(12, 8, 0, 'Contact your Supplier <img src="images/exclam.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/> <a href="links.html">Mouse companies</a>'),
(13, 2, 10, 'Cable is connected'),
(14, 2, 11, 'Cable is not connected'),
(15, 10, 0, 'Contact your Supplier <img src="images/exclam.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/> <a href="links.html">Mouse companies</a>'),
(16, 11, 0, 'Connect cable <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>');

-- --------------------------------------------------------

--
-- Δομή Πίνακα για τον Πίνακα `psu`
--

CREATE TABLE IF NOT EXISTS `psu` (
  `idPSU` int(11) NOT NULL AUTO_INCREMENT,
  `start` int(11) DEFAULT NULL,
  `stop` int(11) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`idPSU`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- 'Αδειασμα δεδομένων του πίνακα `psu`
--

INSERT INTO `psu` (`idPSU`, `start`, `stop`, `text`) VALUES
(1, 1, 2, 'Power Supply Cable is Connected'),
(2, 1, 3, 'Power Supply Cable is not Connected'),
(3, 3, 0, 'Connect Power Supply Cable <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>'),
(4, 2, 4, 'Switch is in "0"'),
(5, 2, 5, 'Switch is in "1"'),
(6, 5, 0, 'Contact your Company <img src="images/exclam.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/> <a href="links.html">PSU companies</a> '),
(7, 4, 0, 'Switch in "1" <img src="images/tick.png" alt="ok" width="5%" onClick="location.href=''troubleshoot.php''"/>');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
